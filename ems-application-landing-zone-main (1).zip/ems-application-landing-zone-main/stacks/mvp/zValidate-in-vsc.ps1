$sn  = "sub-zue-dv-ems"
$sid = "4001930d-8b0c-41e7-8b0b-0ce31c33fd5c"
$tn  = "40376e37-b80e-4bda-9489-6f390f811502"
$tnn = "accruentsystems.onmicrosoft.com"


az login --use-device-code  --tenant $tn # a1a2578a-8fd3-4595-bb18-7d17df8944b0
az account list
az account set --subscription=$sid # "42a94551-096a-41b0-9b55-549d544206ff" # New Signature - Project Services Azure Subscription",

Set-Location 'C:\Repo\accruent\ems-application-landing-zone\stacks\mvp'

remove-item -Force .\.terraform.lock.hcl
remove-item -Force .\*.plan
terraform fmt -recursive

remove-item -Force -Recurse -Path ".\.terraform"
terraform init
terraform validate
terraform plan -out ems.plan
terraform apply ems.plan