NOW
PL -> MVP TF stack -> mvp.tfstate

VNEXT
HOW MANIFEST -> mini-MANIFEST per TF stack

PL1            -> EMS TF app stack        -> TFSTATE
PL2 (6 stages) -> Region TF stack         -> 6x TFSTTAS
PL3            -> Env TF stack (x5)       -> 5x TFSTATE
PL3 -> (env stack) x?       -> 5? TFSTATE
PL4 -> (stamp stack)x?      -> ? TFSATE
PL5 -> (customer stack)     -> ? TFSTATE




# ems-application-landing-zone

0. To be improved
- lifecycle { ignore_changes = [tags] }  in Azure Validated Modules
- make subnet names generic (exclude reference to region, environment)
- make KV,SA name unique (or increase the index)
- unmarshalling response: could not parse response body
- pin terraform version, azurerm provider version
- sa network FW - add the IP of the GitHubRunner (or enable public access)

0. FEEDBACK
- 



1. if possible, use https://azure.github.io/Azure-Verified-Modules/indexes/terraform/tf-resource-modules/

2. EMS resources deployed at 4 levels (reflected in .TF file names):
- app_ - shared by all EMS regions/environments/stamps/customers
- region_ - shared by all environments/stamps/customers in a region
- env_ - shared by all stamps in given region/environment
- stamp_ shared by all customers in a stamp
- customer_ - consumed by a customer


3. Flattehn How To - https://developer.hashicorp.com/terraform/language/functions/flatten
4. 2-tier example - https://github.com/kellystuard/terraform-azure-example/blob/master/infra/main.tf
5. 3-tier example - https://github.com/kellystuard/tf-demo-zone/blob/main/main.tf

6. Stamp 001-999
- 1x AAGW
- 1-99x Service plan
- 1-99x SQL MI

7. RG names

- app
- rg-ems-<description>-<index>
- rg-${local.app_name}-<description>-<index>
- rg-ems-kv-01

- region
- rg-<region>-ems-<description>-<index>
- rg-${module.names.region_short[module.rg_network.object.location]}-${local.app_name}-<description>-<index>
- rg-zue-ems-privatedns-01

- env
- rg-<region>-<env>-ems-<description>-<index>
- rg-${module.names.region_short[module.rg_network.object.location]}-${module.names.env_short[local.region[0].env[0].name]}-${local.app_name}-<description>-<index>
- rg-zue-dv-ems-kv-01

- stamp
- rg-<region>-<env>-ems-<stamp>-<description>-<index>
- rg-${module.names.region_short[module.rg_network.object.location]}-${module.names.env_short[local.region[0].env[0].name]}-${local.app_name}-stamp-${local.region[0].env[0].stamp.index}-sqlmi-${local.region[0].env[0].stamp.sqlmi.index}
- rg-zue-dv-ems-stamp-001-sqlmi-01

- customer
- rg-<region>-<env>-ems-<stamp>-<customer>-<description>-<index>
- rg-${module.names.region_short[module.rg_network.object.location]}-${module.names.env_short[local.region[0].env[0].name]}-${local.app_name}-stamp-${local.region[0].env[0].stamp.index}-<customer>-<description>-<index>
- rg-zue-dv-ems-stamp-001-customer-001-webapp-01
